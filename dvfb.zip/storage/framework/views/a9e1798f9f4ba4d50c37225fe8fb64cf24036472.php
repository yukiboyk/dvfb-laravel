
   <h1>XIN CHÀO CÁC BẠN </h1>
   https://www.svgrepo.com/vectors/code/4
<?php /**PATH E:\laragon\www\dvfb\resources\views/hello.blade.php ENDPATH**/ ?>