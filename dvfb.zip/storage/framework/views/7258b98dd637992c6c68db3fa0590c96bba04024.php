
<body>

<!-- <body data-layout="horizontal"> -->
<?php /**PATH C:\laragon\www\dvfb\resources\views/clients/layouts/body.blade.php ENDPATH**/ ?>