<?php if($errors->any() || session('error') || session('success')): ?>
  <?php $__env->startPush('css'); ?>
  <link rel="stylesheet" href="<?php echo e(URL::asset('assets/libs/sweetalert2/sweetalert2.min.css')); ?>">
  
  <?php $__env->stopPush(); ?>
    <?php $__env->startPush('script'); ?>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="<?php echo e(URL::asset('/assets/libs/sweetalert2/sweetalert2.min.js')); ?>"></script>
        <script>
            <?php if(Session::has('success')): ?>
            Swal.fire({
                 title: 'Thành Công',
                 text: "<?php echo e(session('success')); ?>",
                 icon: 'success',
                 showCancelButton: true,
                 confirmButtonClass: 'btn btn-primary w-xs me-2 mt-2',
                 cancelButtonClass: 'btn btn-danger w-xs mt-2',
                 buttonsStyling: false,
                 showCloseButton: true
                         });
            <?php endif; ?>

            <?php if(Session::has('error')): ?>
            Swal.fire({
                 title: 'Thất bại',
                 text: "<?php echo e(session('error')); ?>",
                 icon: 'error',
                 showCancelButton: true,
                 confirmButtonClass: 'btn btn-primary w-xs me-2 mt-2',
                 cancelButtonClass: 'btn btn-danger w-xs mt-2',
                 buttonsStyling: false,
                 showCloseButton: true
                         });
            <?php endif; ?>
        </script>
    <?php $__env->stopPush(); ?>
<?php endif; ?><?php /**PATH E:\laragon\www\dvfb\resources\views/clients/layouts/alert.blade.php ENDPATH**/ ?>